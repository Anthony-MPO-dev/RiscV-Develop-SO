#include <stdio.h>
//Autor: Anthony M. P. de Oliveira
//Bacharelado em Ciencia da Computacao
//Materia: SOII
int soma(int,int);

int main(){
    int r = soma(2,3);

    printf("Resultado da soma: %d\n\n", r);

    return 0;
}
